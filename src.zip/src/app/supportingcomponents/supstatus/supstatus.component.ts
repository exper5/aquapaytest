import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supstatus',
  templateUrl: './supstatus.component.html',
  styleUrls: ['./supstatus.component.css']
})
export class SupstatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
