import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentreviewdetals',
  templateUrl: './paymentreviewdetals.component.html',
  styleUrls: ['./paymentreviewdetals.component.css']
})
export class PaymentreviewdetalsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
