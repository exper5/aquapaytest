import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paystatus',
  templateUrl: './paystatus.component.html',
  styleUrls: ['./paystatus.component.css']
})
export class PaystatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
