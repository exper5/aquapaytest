import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-lastpayment',
  templateUrl: './lastpayment.component.html',
  styleUrls: ['./lastpayment.component.css']
})
export class LastpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    //---------------------------------------modelbox js start--------------------------------------------
function alignModal() {
  var modalDialog = $(this).find(".modal-dialog");

  // Applying the top margin on modal dialog to align it vertically center
  modalDialog.css("margin-top", Math.max(0, ($(window).height() - modalDialog.height()) / 2));
}
// Align modal when it is displayed
$(".modal").on("shown.bs.modal", alignModal);

// Align modal when user resize the window
$(window).on("resize", function () {
  $(".modal:visible").each(alignModal);
});
//---------------------------------------modelbox js end--------------------------------------------

    //---------------------------------------check box js -------------------------------------------

$(".place").click(function () {
  $(this).toggleClass("green");
});
//---------------------------------------check box js edn-------------------------------------------

//---------------------------------------Prevent anchor default action-------------------------------------------


$('.dropdown-menuu').on('click', function (e) {
  if ($(this).hasClass('dropdown-menuu')) {
      e.stopPropagation();
  }
});

//---------------------------------------Prevent anchor default action-------------------------------------------

//---------------------------------------toggle class for table collapse-------------------------------------------

  $(".row1,.row2,.row3,.row4,.row5").hide();

$('.equipment').click(function () {

  $('.equipment').toggleClass('flashOn flash');
$(".row4").toggle();

});
$('.equipment2').click(function () {

  $('.equipment2').toggleClass('flashOn flash');
$(".row5").toggle();

});
$('.equipment3').click(function () {

  $('.equipment3').toggleClass('flashOn flash');
$(".row1").toggle();

});
$('.equipment4').click(function () {

  $('.equipment4').toggleClass('flashOn flash');
$(".row2").toggle();

});
$('.equipment5').click(function () {

  $('.equipment5').toggleClass('flashOn flash');
$(".row3").toggle();

});
//---------------------------------------toggle class for table collapse-------------------------------------------
  }

}
