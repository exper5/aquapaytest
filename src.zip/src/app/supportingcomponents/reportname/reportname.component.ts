import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportname',
  templateUrl: './reportname.component.html',
  styleUrls: ['./reportname.component.css']
})
export class ReportnameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
