import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toppayment',
  templateUrl: './toppayment.component.html',
  styleUrls: ['./toppayment.component.css']
})
export class ToppaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
