import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asuserapprovemsg',
  templateUrl: './asuserapprovemsg.component.html',
  styleUrls: ['./asuserapprovemsg.component.css']
})
export class AsuserapprovemsgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
