import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asrulesucessmsg',
  templateUrl: './asrulesucessmsg.component.html',
  styleUrls: ['./asrulesucessmsg.component.css']
})
export class AsrulesucessmsgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
