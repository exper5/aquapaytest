import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cardactivity',
  templateUrl: './cardactivity.component.html',
  styleUrls: ['./cardactivity.component.css']
})
export class CardactivityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
