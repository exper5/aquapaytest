import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ascardsuccess',
  templateUrl: './ascardsuccess.component.html',
  styleUrls: ['./ascardsuccess.component.css']
})
export class AscardsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
