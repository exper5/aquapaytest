import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asgroupsuccessmsg',
  templateUrl: './asgroupsuccessmsg.component.html',
  styleUrls: ['./asgroupsuccessmsg.component.css']
})
export class AsgroupsuccessmsgComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
