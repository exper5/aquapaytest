import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-suppliersreport',
  templateUrl: './suppliersreport.component.html',
  styleUrls: ['./suppliersreport.component.css']
})
export class SuppliersreportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
