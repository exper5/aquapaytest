import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ascontactus',
  templateUrl: './ascontactus.component.html',
  styleUrls: ['./ascontactus.component.css']
})
export class AscontactusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
