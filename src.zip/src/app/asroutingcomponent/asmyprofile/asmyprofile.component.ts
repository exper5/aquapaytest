import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asmyprofile',
  templateUrl: './asmyprofile.component.html',
  styleUrls: ['./asmyprofile.component.css']
})
export class AsmyprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
