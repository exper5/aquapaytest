import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asorganisation',
  templateUrl: './asorganisation.component.html',
  styleUrls: ['./asorganisation.component.css']
})
export class AsorganisationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
